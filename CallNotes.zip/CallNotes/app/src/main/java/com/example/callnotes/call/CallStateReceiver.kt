package com.example.callnotes.call

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import com.example.callnotes.reminder.Notifications
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * پایان تماس را با تغییر وضعیت تلفن (RINGING/OFFHOOK → IDLE) تشخیص می‌دهد
 * و یک اعلان «افزودن یادداشت» نشان می‌دهد.
 * شماره از آخرین ردیف CallLog خوانده می‌شود (نیازمند READ_CALL_LOG).
 */
class CallStateReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING,
            TelephonyManager.EXTRA_STATE_OFFHOOK -> wasInCall = true

            TelephonyManager.EXTRA_STATE_IDLE -> {
                if (!wasInCall) return
                wasInCall = false
                val pending = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        // کمی صبر تا سیستم تماس را در CallLog ثبت کند.
                        delay(1500)
                        val phone = lastCallNumber(context)
                        val name = if (phone.isNotBlank()) contactName(context, phone) else ""
                        Notifications.showCallNote(context, phone, name)
                    } finally {
                        pending.finish()
                    }
                }
            }
        }
    }

    private fun granted(context: Context, perm: String) =
        ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED

    private fun lastCallNumber(context: Context): String {
        if (!granted(context, Manifest.permission.READ_CALL_LOG)) return ""
        return runCatching {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER),
                null, null,
                "${CallLog.Calls.DATE} DESC"
            )?.use { c -> if (c.moveToFirst()) c.getString(0).orEmpty() else "" }.orEmpty()
        }.getOrDefault("")
    }

    private fun contactName(context: Context, number: String): String {
        if (!granted(context, Manifest.permission.READ_CONTACTS)) return ""
        return runCatching {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            context.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0).orEmpty() else "" }.orEmpty()
        }.getOrDefault("")
    }

    companion object {
        @Volatile private var wasInCall = false
    }
}
