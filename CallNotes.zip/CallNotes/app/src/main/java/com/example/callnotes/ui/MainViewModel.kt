package com.example.callnotes.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.callnotes.data.AppDatabase
import com.example.callnotes.data.CallNote
import com.example.callnotes.data.Reminder
import com.example.callnotes.reminder.ReminderScheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)

    val notes: StateFlow<List<CallNote>> = db.noteDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val reminders: StateFlow<List<Reminder>> = db.reminderDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun saveNote(note: CallNote) = viewModelScope.launch { db.noteDao().upsert(note) }

    fun deleteNote(note: CallNote) = viewModelScope.launch { db.noteDao().delete(note) }

    fun saveReminder(reminder: Reminder) = viewModelScope.launch {
        val id = db.reminderDao().upsert(reminder)
        val saved = reminder.copy(id = if (reminder.id == 0L) id else reminder.id)
        ReminderScheduler.schedule(getApplication(), saved)
    }

    fun toggleDone(reminder: Reminder) = viewModelScope.launch {
        val updated = reminder.copy(done = !reminder.done)
        db.reminderDao().upsert(updated)
        if (updated.done) ReminderScheduler.cancel(getApplication(), updated)
        else ReminderScheduler.schedule(getApplication(), updated)
    }

    fun deleteReminder(reminder: Reminder) = viewModelScope.launch {
        ReminderScheduler.cancel(getApplication(), reminder)
        db.reminderDao().delete(reminder)
    }
}
