package com.example.callnotes.util

import java.util.Calendar
import java.util.Locale

data class JalaliDate(val year: Int, val month: Int, val day: Int)

/** تبدیل تاریخ میلادی ↔ شمسی، قالب‌بندی فارسی و محاسبه تکرار یادآوری. */
object Jalali {

    val monthNames = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    fun toJalali(gy: Int, gm: Int, gd: Int): JalaliDate {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) +
            ((gy2 + 399) / 400) + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return JalaliDate(jy, jm, jd)
    }

    fun toGregorian(jy: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        val jy2 = jy + 1595
        var days = -355668 + (365 * jy2) + ((jy2 / 33) * 8) + (((jy2 % 33) + 3) / 4) + jd +
            (if (jm < 7) (jm - 1) * 31 else ((jm - 7) * 30) + 186)
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days--
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
        val sal = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 0
        while (gm < 13 && gd > sal[gm]) {
            gd -= sal[gm]
            gm++
        }
        return Triple(gy, gm, gd)
    }

    fun fromMillis(ms: Long): JalaliDate {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        return toJalali(c[Calendar.YEAR], c[Calendar.MONTH] + 1, c[Calendar.DAY_OF_MONTH])
    }

    /** همان ساعت و دقیقه‌ی base را نگه می‌دارد و فقط روز را به تاریخ شمسی داده‌شده تغییر می‌دهد. */
    fun withDate(baseMs: Long, jy: Int, jm: Int, jd: Int): Long {
        val (gy, gm, gd) = toGregorian(jy, jm, jd)
        val c = Calendar.getInstance().apply { timeInMillis = baseMs }
        c.set(gy, gm - 1, gd)
        return c.timeInMillis
    }

    fun isLeap(jy: Int): Boolean {
        val (gy, gm, gd) = toGregorian(jy, 12, 30)
        return toJalali(gy, gm, gd) == JalaliDate(jy, 12, 30)
    }

    fun daysInMonth(jy: Int, jm: Int): Int = when {
        jm <= 6 -> 31
        jm <= 11 -> 30
        else -> if (isLeap(jy)) 30 else 29
    }

    fun toPersianDigits(s: String): String =
        s.map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

    /** مثال: ۱۴۰۵/۰۷/۱۲  ۲۲:۴۹ */
    fun format(ms: Long): String {
        val d = fromMillis(ms)
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        val s = String.format(
            Locale.US, "%04d/%02d/%02d  %02d:%02d",
            d.year, d.month, d.day, c[Calendar.HOUR_OF_DAY], c[Calendar.MINUTE]
        )
        return toPersianDigits(s)
    }

    // ---------- تکرار ----------

    const val REPEAT_NONE = 0
    const val REPEAT_DAILY = 1
    const val REPEAT_WEEKLY = 2
    const val REPEAT_MONTHLY = 3

    private fun addDays(ms: Long, n: Int): Long {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        c.add(Calendar.DAY_OF_YEAR, n)
        return c.timeInMillis
    }

    /** n ماه شمسی جلو می‌رود؛ اگر روز در ماه مقصد وجود نداشت، به آخرین روز آن ماه می‌رود. */
    fun addMonths(ms: Long, n: Int): Long {
        val d = fromMillis(ms)
        val total = d.year * 12 + (d.month - 1) + n
        val y = total / 12
        val m = total % 12 + 1
        return withDate(ms, y, m, minOf(d.day, daysInMonth(y, m)))
    }

    /** اولین زمان تکرار که بعد از now باشد. اگر تکراری نباشد، همان dueAt برمی‌گردد. */
    fun nextAfter(dueAt: Long, repeat: Int, now: Long): Long {
        if (repeat == REPEAT_NONE) return dueAt
        var next = dueAt
        var guard = 0
        while (next <= now && guard++ < 5000) {
            next = when (repeat) {
                REPEAT_DAILY -> addDays(next, 1)
                REPEAT_WEEKLY -> addDays(next, 7)
                REPEAT_MONTHLY -> addMonths(next, 1)
                else -> return dueAt
            }
        }
        return next
    }
}
