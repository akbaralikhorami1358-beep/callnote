package com.example.callnotes.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.callnotes.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** بعد از ریبوت گوشی، آلارم‌های آینده دوباره ثبت می‌شوند. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(context).reminderDao()
                dao.upcoming(System.currentTimeMillis()).forEach {
                    ReminderScheduler.schedule(context, it)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
