package com.example.callnotes.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.callnotes.data.CallNote
import com.example.callnotes.data.Reminder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(
    viewModel: MainViewModel,
    pendingNote: Pair<String, String>?,
    onPendingConsumed: () -> Unit
) {
    val notes by viewModel.notes.collectAsState()
    val reminders by viewModel.reminders.collectAsState()

    var tab by remember { mutableIntStateOf(0) }
    var editingNote by remember { mutableStateOf<CallNote?>(null) }
    var editingReminder by remember { mutableStateOf<Reminder?>(null) }

    // اعلان پایان تماس → صفحه یادداشت جدید با شماره‌ی تماس
    LaunchedEffect(pendingNote) {
        pendingNote?.let { (phone, name) ->
            tab = 0
            editingNote = CallNote(phoneNumber = phone, contactName = name)
            onPendingConsumed()
        }
    }

    val noteToEdit = editingNote
    val reminderToEdit = editingReminder

    when {
        noteToEdit != null -> NoteEditorScreen(
            initial = noteToEdit,
            onSave = { viewModel.saveNote(it); editingNote = null },
            onDelete = { viewModel.deleteNote(it); editingNote = null },
            onBack = { editingNote = null }
        )

        reminderToEdit != null -> ReminderEditorScreen(
            initial = reminderToEdit,
            onSave = { viewModel.saveReminder(it); editingReminder = null },
            onBack = { editingReminder = null }
        )

        else -> Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Icon(Icons.Filled.EditNote, null) },
                        label = { Text("یادداشت‌ها") }
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Icon(Icons.Filled.Alarm, null) },
                        label = { Text("یادآوری‌ها") }
                    )
                }
            },
            floatingActionButton = {
                FloatingActionButton(onClick = {
                    if (tab == 0) editingNote = CallNote()
                    else editingReminder = Reminder(
                        title = "",
                        dueAt = System.currentTimeMillis() + 60 * 60 * 1000
                    )
                }) { Icon(Icons.Filled.Add, contentDescription = "افزودن") }
            }
        ) { padding ->
            if (tab == 0) {
                NotesListScreen(
                    notes = notes,
                    onOpen = { editingNote = it },
                    modifier = Modifier.padding(padding)
                )
            } else {
                RemindersListScreen(
                    reminders = reminders,
                    onOpen = { editingReminder = it },
                    onToggle = viewModel::toggleDone,
                    onDelete = viewModel::deleteReminder,
                    modifier = Modifier.padding(padding)
                )
            }
        }
    }
}
