package com.example.callnotes.ui

import android.app.TimePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.callnotes.data.CallNote
import com.example.callnotes.data.Reminder
import com.example.callnotes.util.Jalali
import java.util.Calendar

private fun fmt(ms: Long): String = Jalali.format(ms)

/** ارقام فارسی/عربی را به لاتین و «ي/ك» عربی را به «ی/ک» تبدیل می‌کند تا جست‌وجو دقیق‌تر شود. */
private fun norm(s: String): String = s.map {
    when (it) {
        in '۰'..'۹' -> '0' + (it - '۰')
        in '٠'..'٩' -> '0' + (it - '٠')
        'ي' -> 'ی'
        'ك' -> 'ک'
        else -> it
    }
}.joinToString("").lowercase()

private fun repeatLabel(repeat: Int): String = when (repeat) {
    Jalali.REPEAT_DAILY -> "روزانه"
    Jalali.REPEAT_WEEKLY -> "هفتگی"
    Jalali.REPEAT_MONTHLY -> "ماهانه"
    else -> ""
}

@Composable
private fun SearchField(query: String, onChange: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value = query,
        onValueChange = onChange,
        singleLine = true,
        placeholder = { Text(hint) },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onChange("") }) {
                    Icon(Icons.Filled.Close, contentDescription = "پاک کردن")
                }
            }
        },
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
private fun EmptyState(message: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(message)
    }
}

// ---------------- لیست یادداشت‌ها ----------------

@Composable
fun NotesListScreen(
    notes: List<CallNote>,
    onOpen: (CallNote) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(notes, query) {
        val q = norm(query.trim())
        if (q.isEmpty()) notes
        else notes.filter {
            norm(it.contactName).contains(q) || norm(it.phoneNumber).contains(q) || norm(it.text).contains(q)
        }
    }

    Column(modifier.fillMaxSize()) {
        if (notes.isNotEmpty()) {
            SearchField(query, { query = it }, "جست‌وجو در یادداشت‌ها (نام، شماره، متن)")
        }
        when {
            notes.isEmpty() -> EmptyState(
                "هنوز یادداشتی ندارید.\nبعد از هر تماس می‌توانید یادداشت بنویسید.",
                Modifier.weight(1f)
            )

            filtered.isEmpty() -> EmptyState("نتیجه‌ای پیدا نشد.", Modifier.weight(1f))

            else -> LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered, key = { it.id }) { note ->
                    Card(Modifier.fillMaxWidth().clickable { onOpen(note) }) {
                        Column(Modifier.padding(16.dp)) {
                            val who = note.contactName.ifBlank { note.phoneNumber.ifBlank { "یادداشت آزاد" } }
                            Text(who, style = MaterialTheme.typography.titleMedium)
                            if (note.contactName.isNotBlank() && note.phoneNumber.isNotBlank()) {
                                Text(note.phoneNumber, style = MaterialTheme.typography.bodySmall)
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(note.text, maxLines = 3, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(fmt(note.createdAt), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

// ---------------- ویرایش یادداشت ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditorScreen(
    initial: CallNote,
    onSave: (CallNote) -> Unit,
    onDelete: (CallNote) -> Unit,
    onBack: () -> Unit
) {
    var phone by remember { mutableStateOf(initial.phoneNumber) }
    var name by remember { mutableStateOf(initial.contactName) }
    var text by remember { mutableStateOf(initial.text) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (initial.id == 0L) "یادداشت جدید" else "ویرایش یادداشت") },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                }
            },
            actions = {
                if (initial.id != 0L) {
                    IconButton(onClick = { onDelete(initial) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "حذف")
                    }
                }
            }
        )
    }) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("نام مخاطب") }, modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            OutlinedTextField(
                value = phone, onValueChange = { phone = it },
                label = { Text("شماره تلفن") }, modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                label = { Text("یادداشت تماس") },
                modifier = Modifier.fillMaxWidth().weight(1f)
            )
            Button(
                onClick = {
                    onSave(initial.copy(phoneNumber = phone.trim(), contactName = name.trim(), text = text.trim()))
                },
                enabled = text.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("ذخیره") }
        }
    }
}

// ---------------- لیست یادآوری‌ها ----------------

@Composable
fun RemindersListScreen(
    reminders: List<Reminder>,
    onOpen: (Reminder) -> Unit,
    onToggle: (Reminder) -> Unit,
    onDelete: (Reminder) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(reminders, query) {
        val q = norm(query.trim())
        if (q.isEmpty()) reminders
        else reminders.filter { norm(it.title).contains(q) || norm(it.phoneNumber).contains(q) }
    }

    Column(modifier.fillMaxSize()) {
        if (reminders.isNotEmpty()) {
            SearchField(query, { query = it }, "جست‌وجو در یادآوری‌ها")
        }
        when {
            reminders.isEmpty() -> EmptyState("یادآوری ثبت نشده است.", Modifier.weight(1f))
            filtered.isEmpty() -> EmptyState("نتیجه‌ای پیدا نشد.", Modifier.weight(1f))
            else -> LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered, key = { it.id }) { r ->
                    val overdue = !r.done && r.dueAt < System.currentTimeMillis()
                    Card(Modifier.fillMaxWidth().clickable { onOpen(r) }) {
                        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = r.done, onCheckedChange = { onToggle(r) })
                            Column(Modifier.weight(1f)) {
                                Text(
                                    r.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    textDecoration = if (r.done) TextDecoration.LineThrough else null
                                )
                                Text(
                                    fmt(r.dueAt),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (overdue) MaterialTheme.colorScheme.error
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (r.repeat != Jalali.REPEAT_NONE) {
                                    Text(
                                        "تکرار ${repeatLabel(r.repeat)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                if (r.phoneNumber.isNotBlank()) {
                                    Text(r.phoneNumber, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            IconButton(onClick = { onDelete(r) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "حذف")
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- ویرایش یادآوری ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReminderEditorScreen(
    initial: Reminder,
    onSave: (Reminder) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(initial.title) }
    var phone by remember { mutableStateOf(initial.phoneNumber) }
    var dueAt by remember { mutableStateOf(initial.dueAt) }
    var repeat by remember { mutableIntStateOf(initial.repeat) }
    var showDatePicker by remember { mutableStateOf(false) }

    if (showDatePicker) {
        JalaliDatePickerDialog(
            initialMs = dueAt,
            onDismiss = { showDatePicker = false },
            onConfirm = { y, m, d ->
                dueAt = Jalali.withDate(dueAt, y, m, d)
                showDatePicker = false
            }
        )
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (initial.id == 0L) "یادآوری جدید" else "ویرایش یادآوری") },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                }
            }
        )
    }) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = title, onValueChange = { title = it },
                label = { Text("عنوان قرار / موعد") }, modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            OutlinedTextField(
                value = phone, onValueChange = { phone = it },
                label = { Text("شماره مرتبط (اختیاری)") }, modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Text("زمان: ${fmt(dueAt)}", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showDatePicker = true }) { Text("انتخاب تاریخ") }

                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = dueAt }
                    TimePickerDialog(context, { _, h, min ->
                        val n = Calendar.getInstance().apply {
                            timeInMillis = dueAt
                            set(Calendar.HOUR_OF_DAY, h)
                            set(Calendar.MINUTE, min)
                            set(Calendar.SECOND, 0)
                        }
                        dueAt = n.timeInMillis
                    }, c[Calendar.HOUR_OF_DAY], c[Calendar.MINUTE], true).show()
                }) { Text("انتخاب ساعت") }
            }

            Text("تکرار", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Jalali.REPEAT_NONE to "بدون تکرار",
                    Jalali.REPEAT_DAILY to "روزانه",
                    Jalali.REPEAT_WEEKLY to "هفتگی",
                    Jalali.REPEAT_MONTHLY to "ماهانه"
                ).forEach { (value, label) ->
                    FilterChip(
                        selected = repeat == value,
                        onClick = { repeat = value },
                        label = { Text(label) }
                    )
                }
            }

            Button(
                onClick = {
                    onSave(
                        initial.copy(
                            title = title.trim(),
                            phoneNumber = phone.trim(),
                            dueAt = dueAt,
                            repeat = repeat
                        )
                    )
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("ذخیره و تنظیم هشدار") }
        }
    }
}

// ---------------- انتخابگر تاریخ شمسی ----------------

@Composable
fun JalaliDatePickerDialog(
    initialMs: Long,
    onDismiss: () -> Unit,
    onConfirm: (year: Int, month: Int, day: Int) -> Unit
) {
    val init = remember { Jalali.fromMillis(initialMs) }
    var year by remember { mutableIntStateOf(init.year) }
    var month by remember { mutableIntStateOf(init.month) }
    var day by remember { mutableIntStateOf(init.day) }

    // اگر ماه/سال عوض شود و روز انتخاب‌شده در آن ماه وجود نداشته باشد، به آخرین روز ماه محدود می‌شود.
    val maxDay = Jalali.daysInMonth(year, month)
    val shownDay = minOf(day, maxDay)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("انتخاب تاریخ شمسی") },
        text = {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stepper(
                    label = "روز",
                    value = Jalali.toPersianDigits(shownDay.toString()),
                    onUp = { day = if (shownDay >= maxDay) 1 else shownDay + 1 },
                    onDown = { day = if (shownDay <= 1) maxDay else shownDay - 1 }
                )
                Stepper(
                    label = "ماه",
                    value = Jalali.monthNames[month - 1],
                    onUp = { month = if (month >= 12) 1 else month + 1 },
                    onDown = { month = if (month <= 1) 12 else month - 1 }
                )
                Stepper(
                    label = "سال",
                    value = Jalali.toPersianDigits(year.toString()),
                    onUp = { year += 1 },
                    onDown = { if (year > 1300) year -= 1 }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(year, month, shownDay) }) { Text("تأیید") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
private fun Stepper(label: String, value: String, onUp: () -> Unit, onDown: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        IconButton(onClick = onUp) {
            Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "افزایش $label")
        }
        Text(value, style = MaterialTheme.typography.titleMedium)
        IconButton(onClick = onDown) {
            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "کاهش $label")
        }
    }
}
