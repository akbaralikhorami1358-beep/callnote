package com.example.callnotes.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query("SELECT * FROM call_notes ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<CallNote>>

    @Query("SELECT * FROM call_notes WHERE id = :id")
    suspend fun get(id: Long): CallNote?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: CallNote): Long

    @Delete
    suspend fun delete(note: CallNote)
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY done ASC, dueAt ASC")
    fun observeAll(): Flow<List<Reminder>>

    @Query("SELECT * FROM reminders WHERE done = 0 AND dueAt > :now")
    suspend fun upcoming(now: Long): List<Reminder>

    @Query("SELECT * FROM reminders WHERE id = :id")
    suspend fun get(id: Long): Reminder?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(reminder: Reminder): Long

    @Delete
    suspend fun delete(reminder: Reminder)
}
