package com.example.callnotes.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/** یادداشت مربوط به یک تماس (یا یادداشت آزاد اگر شماره خالی باشد). */
@Entity(tableName = "call_notes")
data class CallNote(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val phoneNumber: String = "",
    val contactName: String = "",
    val text: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/** یادآوری موعد قرار؛ می‌تواند به یک تماس/شماره وابسته باشد. */
@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val phoneNumber: String = "",
    val dueAt: Long,
    val done: Boolean = false,
    /** 0 = بدون تکرار، 1 = روزانه، 2 = هفتگی، 3 = ماهانه (شمسی) */
    @ColumnInfo(defaultValue = "0") val repeat: Int = 0
)
