package com.example.callnotes.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.callnotes.data.AppDatabase
import com.example.callnotes.util.Jalali
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(EXTRA_ID, 0L)
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val phone = intent.getStringExtra(EXTRA_PHONE).orEmpty()
        Notifications.showReminder(context, id, title, phone)

        // اگر یادآوری تکراری است، زمان بعدی را محاسبه و آلارم بعدی را ثبت می‌کنیم.
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(context).reminderDao()
                val reminder = dao.get(id)
                if (reminder != null && !reminder.done && reminder.repeat != Jalali.REPEAT_NONE) {
                    val next = Jalali.nextAfter(reminder.dueAt, reminder.repeat, System.currentTimeMillis())
                    val updated = reminder.copy(dueAt = next)
                    dao.upsert(updated)
                    ReminderScheduler.schedule(context, updated)
                }
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val EXTRA_ID = "id"
        const val EXTRA_TITLE = "title"
        const val EXTRA_PHONE = "phone"
    }
}
